def add_text_to_file(filename):
    print("Добро пожаловать!Введите номер телефона для авторизации бота на вашем аккаунте.Пожалуйста вводите свой номер начиная с +7\nПример - +79995456060")
    text = input(": ")
    with open(filename, 'w') as file:  # Изменено на 'w'
        file.write(f'{{ \n"api_id": "20045757", \n"api_hash": "7d3ea0c0d4725498789bd51a9ee02421", \n"phone_number": "{text}" \n}}\n')
    print("Номер успешно добавлен.")

# Используйте функцию, например, так:
add_text_to_file('config.json')