pkg update
pkg upgrate
pip install python
pip install git
pip install --quiet telethon
git clone
unzip userbot
cd userbot
touch config.json 
python main.py
clear
python bot.py